clear;
%TASK-1
function it = fractal(c)% function name fractal
% c is complex no
    z = 0;              
    it = 0;              
    iterations = 100; %limits iterations so it does not run forever   
    while it < iterations && abs(z) <= 2 
        z  = z*z + c;%Mandelbrot recurrence relation     
        it = it + 1;%increases iteration
    end
    if abs(z) <= 2 %if it doesn't escape after 100 tries the function returns 0
        it = 0;
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%TASK-2
function fn = indicator_fn_at_x(x) % x is real no
    fn = @(y) (fractal(x + 1i*y) > 0) * 2 - 1;
    % +1 if the point outside the set
    % −1 if the point inside the set
end

function m = bisection(fn_f, s, e)
%finds where the function changes sign
    tolerance = 1e-6;%1e-6 means 1×10^-6=0.000001(precision or stop)
    iterations = 100;%max no of steps
    val_s = fn_f(s);
    val_e = fn_f(e);
    if val_s * val_e > 0
        m = NaN;                        
        return
    end
    for step = 1:iterations
        m = 0.5*(s + e);%midpoint
        val_mid = fn_f(m);

        if val_mid == 0 || (e - s) < tolerance%Stop if midpoint accurate
            return                       
        end

        if val_s * val_mid > 0
            s = m;  
            val_s = val_mid;% sign same as s then move s
        else
            e = m;  
            val_e = val_mid;% sign same as e then move e
        end
    end
    m = 0.5*(s + e);                     %midpoint
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%TASK-4
function l = poly_len(p, s, e)
%polynomial coefficients
% s is starting value
% e is ending value
    if e < s
        tmp = s; 
        s = e; 
        e = tmp; 
    end    % ensure s<=e
    dp = polyder(p);% derivative of the polynomial                           
    ds = @(x) sqrt(1 + (polyval(dp, x)).^2);%anonymous function
    l = integral(ds, s, e);% matlab integral function                  
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%MAIN
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%TASK-1
disp('TASK-1')
disp(fractal(0))         
disp(fractal(1 + 1.5i))  

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%TASK-2
x_vals = linspace(-2, 1, 1000);%1000 points range is -2 to +1
y_vals = zeros(size(x_vals));%imaginary boundary intially zero

for k = 1:numel(x_vals)
    fn = indicator_fn_at_x(x_vals(k));%checks whether c is inside or outside
    y_vals(k) = bisection(fn, 0, 2); %stores values    
end

disp('TASK-2')
disp('Sample boundary points (Re, Im):');
disp([x_vals(1:10)' y_vals(1:10)']);%first 10 boundary points

% plot
figure;
plot(x_vals(~isnan(y_vals)), y_vals(~isnan(y_vals)), '.');
xlabel('Real'); 
ylabel('Imaginary'); 
grid on
title('Task 2: Mandelbrot Boundary ');

fn = indicator_fn_at_x(-0.5);%test one vertical line manually at x = −0.5
disp(['y at x=-0.5 ≈ ', num2str(bisection(fn,0,2))]);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%TASK-3
xs = linspace(-2, 1, 1000);% again computing task 2 with 1000
ys = zeros(size(xs));
for i = 1:numel(xs)
    fn = indicator_fn_at_x(xs(i));
    ys(i) = bisection(fn, 0, 2);
end

figure;
plot(xs(~isnan(ys)), ys(~isnan(ys)), '.'); 
grid on
xlabel('Real'); 
ylabel('Imaginary');
title('Task 3 ');
%hand tune helps cropping the boundary
x_min_keep = -1.85;   
x_max_keep =  0.30;   
xline(x_min_keep,'--'); xline(x_max_keep,'--');
%keeps only valid points
valid = ~isnan(ys) & ys > 0 & ys < 1.5 & ...
        xs >= x_min_keep & xs <= x_max_keep;

xfit = xs(valid);
yfit = ys(valid);

if numel(xfit) < 20
    error('Very Few points after hand-tuning; adjust x_min_keep/x_max_keep.');
end


deg = 15;%15th order polynomial
p = polyfit(xfit, yfit, deg);


xplot = linspace(min(xfit), max(xfit), 1200);
yhat  = polyval(p, xplot);
rmse  = sqrt(mean((polyval(p, xfit) - yfit).^2));%how well it fits


figure;
plot(xs(~isnan(ys)), ys(~isnan(ys)), '.', 'DisplayName','all boundary'); 
hold on
plot(xfit, yfit, '.', 'DisplayName','used for fit');
plot(xplot, yhat, 'LineWidth',1.5, 'DisplayName','15th-order fit');
xlabel('Real'); 
ylabel('Imaginary'); 
grid on
title('Task 3: Hand-tuned boundary and 15th order polynomial fit');
legend('Location','best');


disp('TASK-3')
disp('Polynomial coefficients (highest power first):');
disp(p);
disp(['RMSE on fit points: ', num2str(rmse)]);
disp(['Estimated Im at x = 0: ', num2str(polyval(p, 0))]);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%TASK-4
%computes curve length
s = min(xfit);%range 
e = max(xfit);
len = poly_len(p, s, e);%arc length
disp('TASK-4')
disp(['Approx. curve length over [', num2str(s), ', ', num2str(e), ']: ', num2str(len)]);


